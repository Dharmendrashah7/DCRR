# Eliam ordering system
 
user Detail 
 
 email  -  rohit@gmail.com
 password - 123456


 admin 
 user - admin
 password - admin
<div class="footer">
            
            <div>
                <strong>Copyright @</strong> RRDC &copy;<?php echo date('Y');?>
            </div>
        </div>
<?php
$con=mysqli_connect("localhost", "root", "", "dcrr");
if(mysqli_connect_errno()){
echo "PLEASE BEAR WITH US AS WE ARE CURRENTLY WORKING ON OUR SITE!!!! PLEASE COME BACK LATER".mysqli_connect_error();
}

  ?>
